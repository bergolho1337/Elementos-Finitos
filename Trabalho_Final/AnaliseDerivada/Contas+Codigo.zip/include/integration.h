#ifndef INTEGRATION_H_
#define INTEGRATION_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "functions.h"

#define H 1.0e-06                                // Tamanho dos trapezios usados na integracao

#endif
